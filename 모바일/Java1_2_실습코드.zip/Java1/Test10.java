package Java1;

public class Test10 {
	
	public static int ForTest() {
		int sum = 0;
		for(int i = 0; i < 100; i += 2) {
			sum += i;
		}
		return sum;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum = 0;
		sum = ForTest();
		System.out.println(sum);
	}

}
