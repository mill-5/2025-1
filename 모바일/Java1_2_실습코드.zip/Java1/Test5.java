package Java1;
import java.util.Scanner;

public class Test5 {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.print("정수 3개 입력 >> ");
		int a = 0, b = 0, c = 0;
		a = input.nextInt();
		b = input.nextInt();
		c = input.nextInt();
		
		if(a > b && a > c) {
			if(b > c)
				System.out.println("중간 값은 " + b);
			else if(b < c)
				System.out.println("중간 값은 " + c);
		}
		else if(b > a && b > c) {
			if(a > c)
				System.out.println("중간 값은 " + a);
			else if(a < c)
				System.out.println("중간 값은 " + c);
		}
		else if(c > a && c > b) {
			if(a > b)
				System.out.println("중간 값은 " + a);
			else if(a < b)
				System.out.println("중간 값은 " + b);
		}
	}
}
