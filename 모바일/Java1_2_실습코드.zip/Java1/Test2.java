package Java1;

import java.util.Scanner;

public class Test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.print("원화를 입력하세요(단위 원) >> ");
		float won = input.nextFloat();
		System.out.println(won + "원은 $" + won / 1100.0 + "입니다.");
	}

}
