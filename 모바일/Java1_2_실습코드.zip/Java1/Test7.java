package Java1;
import java.util.Scanner;

public class Test7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.print("첫번째 원의 중심과 반지름 입력 >> ");
		double x1 = input.nextDouble();
		double y1 = input.nextDouble();
		double radius1 = input.nextDouble();
		System.out.print("두번째 원의 중심과 반지름 입력 >> ");
		double x2 = input.nextDouble();
		double y2 = input.nextDouble();
		double radius2 = input.nextDouble();
		
		double length = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
		if(length <= radius1 + radius2) {
			System.out.println("두 원이 겹칩니다.");
		}else {
			System.out.println("두 원이 겹치지 않습니다.");
		}
			
	}

}
