package Java1;

public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Welcome!!");
		System.out.println("자바 세계로 오신 것을 환영합니다.");
	}

}
