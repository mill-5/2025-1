package Java1;
import java.util.Scanner;

public class Test6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.print("정수 3개를 입력하시오 >> ");
		int a = 0, b = 0, c = 0;
		a = input.nextInt();
		b = input.nextInt();
		c = input.nextInt();
		
		int max = a, x = b, y = c;
		if(max < b) { max = b; x = a; y = c; }
		else if(max < c) { c = max; x = a; y = b; }
		
		if(max < x + y)
			System.out.println("삼각형이 됩니다.");
		else
			System.out.println("삼각형이 안 됩니다.");
	}

}
