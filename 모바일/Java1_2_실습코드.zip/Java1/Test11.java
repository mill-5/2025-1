package Java1;

public class Test11 {
	
	public static int DoWhileTest() {
		int sum = 0, i = 0;
		do {
			sum += i;
			i += 2;
		}while(i < 100);
		
		return sum;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum = 0;
		sum = DoWhileTest();
		System.out.println(sum);
	}

}
