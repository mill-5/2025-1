package Java1;
import java.util.Scanner;

public class Test4 {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.print("금액을 입력하시오. >> ");
		int money = input.nextInt();
		
		int 오만원권 = 0, 만원권 = 0, 천원권 = 0, 백원 = 0, 오십원 = 0, 십원 = 0, 일원  = 0;
		int cnt = 0;
		if(money > 50000) {
			cnt = money / 50000;
			money -= 50000 * cnt;
			오만원권 += cnt;
		}
		if(money > 10000) {
			cnt = money / 10000;
			money -= 10000 * cnt;
			만원권 += cnt;
		}
		if(money > 1000) {
			cnt = money / 1000;
			money -= 1000 * cnt;
			천원권 += cnt;
		}
		if(money > 100) {
			cnt = money / 100;
			money -= 100 * cnt;
			백원 += cnt;
		}
		if(money > 50) {
			cnt = money / 50;
			money -= 50 * cnt;
			오십원 += cnt;
		}
		if(money > 10) {
			cnt = money / 10;
			money -= 10 * cnt;
			십원 += cnt;
		}
		if(money > 1) {
			cnt = money % 10;
			money -= 10 * cnt;
			일원 += cnt;
		}
		System.out.println("오만원권 " + 오만원권 +"매");
		System.out.println("만원권 " + 만원권 +"매");
		System.out.println("천원원권 " + 천원권 +"매");
		System.out.println("백원 " + 백원 +"개");
		System.out.println("오십원 " + 오십원 +"개");
		System.out.println("십원 " + 십원 +"개");
		System.out.println("일원 " + 일원 +"개");
	}
}
