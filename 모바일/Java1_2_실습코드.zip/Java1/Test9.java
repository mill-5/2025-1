package Java1;

public class Test9 {
	
	public static int WhileTest(int sum, int i) {
		while(i < 100) {
			sum = sum + i;
			i += 2;
		}
		return sum;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum = 0, i = 0;
		sum = WhileTest(sum, i);
		System.out.println(sum);
	}

}
