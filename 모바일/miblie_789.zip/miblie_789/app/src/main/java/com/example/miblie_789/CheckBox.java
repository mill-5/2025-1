package com.example.miblie_789;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class CheckBox extends AppCompatActivity {

    private ImageView imageView;
    private float currentRotation = 0f; // 현재 회전 각도 저장

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.checkbox);

        // XML 요소 연결
        imageView = findViewById(R.id.image_view);
        Button rotateButton = findViewById(R.id.rotate_button);

        // 버튼 클릭 시 이미지 회전
        rotateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentRotation += 10f; // 10도씩 증가
                imageView.setRotation(currentRotation); // 회전 적용
            }
        });
    }
}